bl_info = {
    "name": "Measure Distance and Angle",
    "blender": (2, 83, 0),
    "category": "3D View",
}

import bpy
from .modules.operators import (
    MeasureDistanceOperator,
    HideDistanceOperator,
    MeasureAngleOperator
)
from .modules.panel import MeasureDistancePanel
from .modules.modal_operator import MeasureDistanceModalOperator

classes = (
    MeasureDistanceOperator,
    HideDistanceOperator,
    MeasureAngleOperator,
    MeasureDistancePanel,
    MeasureDistanceModalOperator
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
