import bpy

class MeasureDistancePanel(bpy.types.Panel):
    bl_label = "Measure Distance and Angle"
    bl_idname = "VIEW3D_PT_measure_distance"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Tool'
    
    def draw(self, context):
        layout = self.layout
        layout.operator("view3d.measure_distance")
        layout.operator("view3d.hide_distance")
        layout.operator("view3d.measure_angle")

def register():
    bpy.utils.register_class(MeasureDistancePanel)

def unregister():
    bpy.utils.unregister_class(MeasureDistancePanel)
