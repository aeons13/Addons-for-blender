import bpy
import math
from .utils import calculate_angle

class MeasureDistanceOperator(bpy.types.Operator):
    bl_idname = "view3d.measure_distance"
    bl_label = "Measure Distance"
    
    def execute(self, context):
        bpy.context.space_data.overlay.show_extra_edge_length = True
        bpy.ops.view3d.modal_operator('INVOKE_DEFAULT')
        return {'RUNNING_MODAL'}

class HideDistanceOperator(bpy.types.Operator):
    bl_idname = "view3d.hide_distance"
    bl_label = "Hide Distance"
    
    def execute(self, context):
        bpy.context.space_data.overlay.show_extra_edge_length = False
        return {'FINISHED'}

class MeasureAngleOperator(bpy.types.Operator):
    bl_idname = "view3d.measure_angle"
    bl_label = "Measure Angle"
    
    def execute(self, context):
        angle = calculate_angle(context)
        self.report({'INFO'}, f"Angle: {math.degrees(angle):.2f} degrees")
        return {'FINISHED'}

def register():
    bpy.utils.register_class(MeasureDistanceOperator)
    bpy.utils.register_class(HideDistanceOperator)
    bpy.utils.register_class(MeasureAngleOperator)

def unregister():
    bpy.utils.unregister_class(MeasureDistanceOperator)
    bpy.utils.unregister_class(HideDistanceOperator)
    bpy.utils.unregister_class(MeasureAngleOperator)
