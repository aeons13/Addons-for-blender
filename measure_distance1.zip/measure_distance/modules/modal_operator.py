import bpy
import bgl
import blf
import mathutils

class MeasureDistanceModalOperator(bpy.types.Operator):
    bl_idname = "view3d.modal_operator"
    bl_label = "Measure Distance Modal Operator"

    def __init__(self):
        self.start_point = None
        self.end_point = None
        self.distance = 0.0

    def modal(self, context, event):
        context.area.tag_redraw()

        if event.type == 'MOUSEMOVE':
            self.end_point = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
            if self.start_point:
                self.distance = (self.start_point - self.end_point).length

        elif event.type == 'LEFTMOUSE':
            if self.start_point is None:
                self.start_point = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
            else:
                self.end_point = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
                self.distance = (self.start_point - self.end_point).length
                self.report({'INFO'}, f"Distance: {self.distance:.2f}")
                self.start_point = None
                self.end_point = None
                return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.area.type == 'VIEW_3D':
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "View3D not found, cannot run operator")
            return {'CANCELLED'}

def draw_callback_px(self, context):
    if self.start_point and self.end_point:
        bgl.glEnable(bgl.GL_BLEND)
        bgl.glLineWidth(2)
        bgl.glColor4f(1.0, 0.0, 0.0, 1.0)
        bgl.glBegin(bgl.GL_LINES)
        bgl.glVertex2f(*self.start_point)
        bgl.glVertex2f(*self.end_point)
        bgl.glEnd()
        bgl.glDisable(bgl.GL_BLEND)

        blf.position(0, self.end_point.x, self.end_point.y, 0)
        blf.size(0, 20, 72)
        blf.draw(0, f"Distance: {self.distance:.2f}")

def register():
    bpy.utils.register_class(MeasureDistanceModalOperator)
    bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, (None, None), 'WINDOW', 'POST_PIXEL')

def unregister():
    bpy.utils.unregister_class(MeasureDistanceModalOperator)
    bpy.types.SpaceView3D.draw_handler_remove(draw_callback_px, 'WINDOW')
