import math
import bpy
import mathutils

def calculate_angle(context):
    # Obtener el objeto activo en modo de edición
    obj = context.active_object
    mesh = obj.data
    
    if obj.mode != 'EDIT':
        raise ValueError("El objeto debe estar en modo de edición")
    
    # Actualizar la malla para reflejar las selecciones actuales
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.mode_set(mode='EDIT')
    
    edges = [e for e in mesh.edges if e.select]
    if len(edges) != 2:
        raise ValueError("Debe seleccionar exactamente dos aristas")

    # Obtener los vértices de las aristas seleccionadas
    verts = set()
    for edge in edges:
        verts.update(edge.vertices)
    
    if len(verts) != 3:
        raise ValueError("Las aristas seleccionadas deben compartir un único vértice")

    # Identificar el vértice común y los dos vértices restantes
    common_vert = [v for v in verts if sum(1 for e in edges if v in e.vertices) == 2][0]
    other_verts = [v for v in verts if v != common_vert]
    
    p1, p2, p3 = [mesh.vertices[v].co for v in (other_verts[0], common_vert, other_verts[1])]
    
    # Calcular los vectores
    vec1 = p1 - p2
    vec2 = p3 - p2
    
    # Calcular el ángulo usando el producto punto
    angle = vec1.angle(vec2)
    return angle

